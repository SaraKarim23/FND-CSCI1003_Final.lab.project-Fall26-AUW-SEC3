// 1. PRODUCT LIST

const products = [
    {emoji: "🎀", name: "Bow clip", price: 80, photo: "clip.jpg"},
    {emoji: "🌸", name: "Hair band", price: 100, photo: "hairband.jpg"},
    {emoji: "📿", name: "Charm bracelet", price: 150, photo: "braclet.jpg"},
    {emoji: "🔑", name: "Keychain", price: 60, photo: "key.jpg"},
    {emoji: "📱", name: "Phone charm", price: 90, photo: "phone charm.jpg"},
    {emoji: "👜", name: "Mini tote bag", price: 350, photo: "tote bag.jpg"},
    {emoji: "🧦", name: "Cute socks", price: 120, photo: "sock.jpg"},
    {emoji: "💄", name: "Lip balm", price: 200, photo: "lip balm.jpg"},
    {emoji: "💍", name: "Sparkle ring", price: 70, photo: "ringset.jpg"},
    {emoji: "🩴", name: "Shoes", price: 130, photo: "shoes.jpg"}
];

// 2. GIFT LIST
const prizes = [
    {name: "Golden Makeup Bag", emoji: "🎀",photo:"makeup bag.jpg"},
    {name: "Sparkle Notepad", emoji: "✨",photo:"notepad.jpg"},
    {name: "Sweet Sticker Pack", emoji: "💖",photo:"sticker.jpg"}
];

// 3. VARIABLES
let quantities = [];

for (let i = 0; i < products.length; i++) {
    quantities.push(0);
}
let wonMemory = false;
let wonCashier = false;
let lastGame = "";

let memCards = [];
let firstPick = -1;
let locked = false;
let memPairs = 0;
let memTime = 40;
let memTimer;

let cashNo = 0;
let cashRight = 0;
let cashTotal = 0;
let cashTime = 15;
let cashTimer;
let boxPrizes = [];

// 4. SCREEN FUNCTION
function showScreen(name) {
    const screens = [
        "home", "shop", "checkout", "games",
        "memory", "cashier", "half",
        "lose", "prizeScreen"
    ];

    for (let i = 0; i < screens.length; i++) {
        document.getElementById(screens[i]).classList.add("hidden");
    }
    document.getElementById(name).classList.remove("hidden");
    window.scrollTo(0, 0);
}

// 5. STOP GAME TIMERS
function stopClocks() {
    clearInterval(memTimer);
    clearInterval(cashTimer);
}

// 6. CALCULATE TOTAL ITEMS
function getTotalItems() {
    let total = 0;
    for (let i = 0; i < quantities.length; i++) {
        total = total + quantities[i];
    }
    return total;
}

// 7. CALCULATE TOTAL PRICE
function getTotalPrice() {

    let total = 0;
    for (let i = 0; i < products.length; i++) {
        total = total + products[i].price * quantities[i];
    }
    return total;
}

// 8. DISPLAY SHOP PRODUCTS
function drawShop() {

    let html = "";

    for (let i = 0; i < products.length; i++) {
        const p = products[i];

        html += '<div class="item">';
        html += '<img src="' + p.photo + '" alt="' + p.name + '">';
        html += '<h3>' + p.emoji + " " + p.name + '</h3>';
        html += '<p class="price">৳' + p.price + '</p>';
        html += '<div class="quantity">';
        html += '<button onclick="changeQuantity(' + i + ',-1)">−</button>';
        html += '<span>' + quantities[i] + '</span>';
        html += '<button onclick="changeQuantity(' + i + ',1)">+</button>';
        html += '</div>';
        html += '</div>';
    }

    document.getElementById("products").innerHTML = html;
    updateBasket();
}

// 9. CHANGE PRODUCT QUANTITY
function changeQuantity(index, amount) {

    quantities[index] = quantities[index] + amount;
    if (quantities[index] < 0) {
        quantities[index] = 0;
    }
    drawShop();
}


// 10. UPDATE BASKET INFORMATION
function updateBasket() {

    const items = getTotalItems();
    const total = getTotalPrice();

    let message = "🛍️ Total items: " + items;
    message += " | Total price: ৳" + total;

    if (items >= 3) {
        message += " | 🎉 Games unlocked!";
    } else {
        message += " | Buy " + (3 - items) + " more item(s) to unlock games.";
    }

    document.getElementById("basketInfo").textContent = message;
    const playBtn = document.getElementById("playBtn");

    if (items >= 3) {
        playBtn.disabled = false;
    } else {
        playBtn.disabled = true;
    }
}

// 11. SHUFFLE ARRAY
function shuffle(list) {

    for (let i = list.length - 1; i > 0; i--) {
        const r = Math.floor(Math.random() * (i + 1));
        const temp = list[i];
        list[i] = list[r];
        list[r] = temp;
    }
    return list;
}

// 12. OPEN CHECKOUT
function openCheckout() {

    stopClocks();

    if (getTotalItems() === 0) {
        alert("Please select at least one product!");
        showScreen("shop");
        return;
    }
    let html = "";
    for (let i = 0; i < products.length; i++) {
        if (quantities[i] > 0) {

            html += "<p>";
            html += products[i].name;
            html += " × " + quantities[i];
            html += " = ৳" + (products[i].price * quantities[i]);
            html += "</p>";
        }
    }

    document.getElementById("orderSummary").innerHTML = html;
    document.getElementById("orderTotal").textContent =
        "Total Amount: ৳" + getTotalPrice();

    document.getElementById("receipt").innerHTML = "";
    document.getElementById("orderForm").classList.remove("hidden");
    showScreen("checkout");
}

// 13. PLACE ORDER AND SHOW RECEIPT
document.getElementById("orderForm").addEventListener("submit", function(event) {

    event.preventDefault();
    const customerName = document.getElementById("customerName").value;
    const payment = document.querySelector('input[name="payment"]:checked');

    if (payment === null) {
        alert("Please select Cash or Card.");
        return;
    }

    let html = "";
    html += '<div class="receipt">';
    html += "<h2>🎀 Kitty Bow Boutique 🎀</h2>";
    html += "<h3>Order Receipt</h3>";
    html += "<p><b>Customer:</b> " + customerName + "</p>";
    html += "<h3>Products:</h3>";

    for (let i = 0; i < products.length; i++) {
        if (quantities[i] > 0) {
            html += "<p>";
            html += products[i].name;
            html += " × " + quantities[i];
            html += " = ৳" + (products[i].price * quantities[i]);
            html += "</p>";
        }
    }
    html += '<h3 class="total">Total Amount: ৳' + getTotalPrice() + '</h3>';
    html += "<p><b>Pay:</b> " + payment.value + "</p>";
    html += "<h3>Thank you for shopping with us! 💗</h3>";
    html += "</div>";

    document.getElementById("receipt").innerHTML = html;
    document.getElementById("orderForm").classList.add("hidden");
});

// 14. OPEN GAMES
function openGames() {

    stopClocks();

    if (getTotalItems() < 3) {
        alert("You need to buy at least 3 items to play!");
        showScreen("shop");
        return;
    }

    let text1 = wonMemory ? "✅ Memory Game Won" : "⬜ Memory Game Not Won";
    let text2 = wonCashier ? "✅ Cashier Game Won" : "⬜ Cashier Game Not Won";

    document.getElementById("gameProgress").textContent =
        text1 + " | " + text2;

    document.getElementById("btnMemory").disabled = wonMemory;
    document.getElementById("btnCashier").disabled = wonCashier;
    showScreen("games");
}

// 15. START MEMORY GAME
function startMemory() {

    lastGame = "memory";
    stopClocks();
    memCards = [];
    for (let i = 0; i < 6; i++) {

        memCards.push({
            emoji: products[i].emoji,
            open: false,
            matched: false
        });

        memCards.push({
            emoji: products[i].emoji,
            open: false,
            matched: false
        });
    }

    shuffle(memCards);

    firstPick = -1;
    locked = false;
    memPairs = 0;
    memTime = 40;

    document.getElementById("memTime").textContent = memTime;
    document.getElementById("memPairs").textContent = memPairs;

    drawCards();
    showScreen("memory");

    memTimer = setInterval(function() {

        memTime--;
        document.getElementById("memTime").textContent = memTime;
        if (memTime <= 0) {
            endGame(false, "Time is up!");
        }

    }, 1000);
}


// 16. DISPLAY MEMORY CARDS

function drawCards() {
    let html = "";
    for (let i = 0; i < memCards.length; i++) {
        const c = memCards[i];

        if (c.matched) {
            html += '<button class="card matched">' + c.emoji + '</button>';
        } else if (c.open) {
            html += '<button class="card open">' + c.emoji + '</button>';
        } else {
            html += '<button class="card" onclick="flipCard(' + i + ')">🎀</button>';
        }
    }

    document.getElementById("cards").innerHTML = html;
}

// 17. FLIP MEMORY CARD
function flipCard(i) {

    if (locked) return;
    if (memCards[i].open || memCards[i].matched) return;
    memCards[i].open = true;

    drawCards();
    if (firstPick === -1) {
        firstPick = i;
        return;
    }
    const a = firstPick;
    const b = i;

    firstPick = -1;
    locked = true;

    setTimeout(function() {
        if (memCards[a].emoji === memCards[b].emoji) {
            memCards[a].matched = true;
            memCards[b].matched = true;
            memPairs++;
            document.getElementById("memPairs").textContent = memPairs;
        }

        memCards[a].open = false;
        memCards[b].open = false;

        locked = false;
        drawCards();

        if (memPairs === 6) {
            endGame(true, "");
        }
    }, 700);
}
// 18. START CASHIER GAME
function startCashier() {
    lastGame = "cashier";
    stopClocks();

    cashNo = 0;
    cashRight = 0;

    showScreen("cashier");
    nextCustomer();
}

// 19. NEXT CUSTOMER
function nextCustomer() {

    cashNo++;
    document.getElementById("cashNo").textContent = cashNo;
    document.getElementById("cashMsg").innerHTML = "";
    const howMany = 2 + Math.floor(Math.random() * 2);
    const start = Math.floor(Math.random() * (products.length - howMany + 1));

    let text = "A customer wants to buy:<br>";

    cashTotal = 0;

    for (let i = start; i < start + howMany; i++) {

        const qty = 1 + Math.floor(Math.random() * 3);

        cashTotal = cashTotal + products[i].price * qty;

        text += qty + " × " + products[i].name;
        text += " (৳" + products[i].price + ")<br>";
    }
    text += "<b>What is the total amount?</b>";
    document.getElementById("cashQuestion").innerHTML = text;

    const answers = shuffle([
        cashTotal,
        cashTotal + 10,
        cashTotal - 10,
        cashTotal + 20
    ]);

    let html = "";
    for (let i = 0; i < answers.length; i++) {

        html += '<button onclick="checkAnswer(' + answers[i] + ')">';
        html += "৳" + answers[i];
        html += "</button>";
    }
    document.getElementById("cashAnswers").innerHTML = html;
    cashTime = 15;
    document.getElementById("cashTime").textContent = cashTime;

    cashTimer = setInterval(function() {
        cashTime--;
        document.getElementById("cashTime").textContent = cashTime;
        if (cashTime <= 0) {
            checkAnswer(-1);
        }
    }, 1000);
}
// 20. CHECK CASHIER ANSWER
function checkAnswer(value) {

    clearInterval(cashTimer);
    const buttons = document.querySelectorAll("#cashAnswers button");
    for (let i = 0; i < buttons.length; i++) {
        buttons[i].disabled = true;
    }

    let message = "";
    if (value === cashTotal) {
        cashRight++;
        message = "✅ Correct! Well done!";
    } else if (value === -1) {
        message = "⏰ Time is up! The correct total was ৳" + cashTotal;
    } else {
        message = "❌ Wrong answer! The correct total was ৳" + cashTotal;
    }

    let label = "Next Customer";

    if (cashNo === 3) {
        label = "Finish Game";
    }
    document.getElementById("cashMsg").innerHTML =
        message +
        '<br><button onclick="afterAnswer()">' + label + '</button>';
}

// 21. AFTER CASHIER ANSWER
function afterAnswer() {
    if (cashNo < 3) {
        nextCustomer();
    } else if (cashRight >= 2) {
        endGame(true, "");
    } else {
        endGame(false, "You got " + cashRight + " correct answers. You need 2.");
    }
}

// 22. CHECK GAME RESULT
function endGame(won, message) {

    stopClocks();
    if (!won) {
        document.getElementById("loseMsg").textContent = message;
        showScreen("lose");
        return;
    }
    if (lastGame === "memory") {
        wonMemory = true;
    } else {
        wonCashier = true;
    }
    if (wonMemory && wonCashier) {
        startPrizeScreen();

    } else {
        let other = wonMemory ? "Cashier Game" : "Memory Game";
        document.getElementById("halfMsg").textContent =
            "You won! Now win the " + other + " to choose your gift.";

        showScreen("half");
    }
}

// 23. START BLIND BOX SCREEN
function startPrizeScreen() {

    boxPrizes = shuffle(prizes.slice());
    let html = "";

    for (let i = 0; i < 3; i++) {
        html += '<button class="box" onclick="openBox(' + i + ')">🎁</button>';
    }
    document.getElementById("boxes").innerHTML = html;
    document.getElementById("prizeResult").innerHTML = "";
    showScreen("prizeScreen");
}

// 24. OPEN ONE BLIND BOX
function openBox(i) {

    const prize = boxPrizes[i];
    const boxes = document.querySelectorAll(".box");

    for (let j = 0; j < boxes.length; j++) {
        boxes[j].disabled = true;
    }

    let html = "";
    html += '<div class="prize">';
    html += "<h2>🎊 Congratulations! 🎊</h2>";
    html += '<div class="gift-picture">' + prize.emoji + '</div>';
    html += "<h3>You won: " + prize.name + "</h3>";
    html += "<p>Thank you for shopping with us!</p>";
    html += "</div>";

    document.getElementById("prizeResult").innerHTML = html;
}
// 25. RESET FOR NEXT CUSTOMER
function playAgain() {

    stopClocks();
    quantities = [];
    for (let i = 0; i < products.length; i++) {
        quantities.push(0);
    }

    wonMemory = false;
    wonCashier = false;
    lastGame = "";

    memCards = [];
    firstPick = -1;
    locked = false;
    memPairs = 0;
    memTime = 40;

    cashNo = 0;
    cashRight = 0;
    cashTotal = 0;
    cashTime = 15;

    boxPrizes = [];
    document.getElementById("orderForm").reset();
    document.getElementById("receipt").innerHTML = "";
    document.getElementById("orderForm").classList.remove("hidden");

    drawShop();

    showScreen("home");
}

// START WEBSITE
drawShop();
showScreen("home");