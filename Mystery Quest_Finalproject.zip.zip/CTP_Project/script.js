// THE OTHER SIDE - COMPLETE GAME JAVASCRIPT

// 1. WEBSITE NAVIGATION
const pages = document.querySelectorAll(".page");
const navigationButtons = document.querySelectorAll("[data-page]");

function showPage(pageId) {
    pages.forEach(page => page.classList.remove("active"));
    const selectedPage = document.getElementById(pageId);
    if (selectedPage) selectedPage.classList.add("active");

    navigationButtons.forEach(button => {
        button.classList.toggle("selected", button.dataset.page === pageId);
    });

    window.scrollTo({ top: 0, behavior: "smooth" });
}

navigationButtons.forEach(button => {
    button.addEventListener("click", event => {
        event.preventDefault();
        showPage(button.dataset.page);
    });
});

document.getElementById("enterBtn")?.addEventListener("click", () => showPage("world"));


// 2. HIDDEN WORLDS
let discoveredWorlds = [];

const worldStories = {
    library: "THE FORGOTTEN LIBRARY: Every book contains a memory someone tried to erase.",
    clock: "THE CLOCKWORK CITY: Every clock stopped at midnight. The city remembers the disappearance.",
    mirror: "THE MIRROR DIMENSION: Your reflection reveals a different reality.",
    garden: "THE LOST GARDEN: Every flower holds an ancient secret.",
    secret: "THE ORIGIN: You have reached the beginning of everything."
};

const worldModal = document.getElementById("worldModal");

function closeWorldModal() {
    if (worldModal) worldModal.style.display = "none";
}

function exploreWorld(worldName) {
    if (!discoveredWorlds.includes(worldName)) discoveredWorlds.push(worldName);

    const story = worldStories[worldName] || "A new mystery awaits.";
    const message = document.getElementById("worldMessage");
    if (message) message.textContent = story;

    if (worldName === "secret") {
        showPage("world");
        document.getElementById("gameArea")?.scrollIntoView({ behavior: "smooth" });
        return;
    }

    const parts = story.split(": ");
    document.getElementById("worldTitle").textContent = parts[0];
    document.getElementById("worldStory").textContent = parts.slice(1).join(": ");
    if (worldModal) worldModal.style.display = "flex";
}

document.querySelectorAll("[data-world]").forEach(button => {
    button.addEventListener("click", () => exploreWorld(button.dataset.world));
});

document.getElementById("closeWorld")?.addEventListener("click", closeWorldModal);

document.getElementById("worldContinue")?.addEventListener("click", () => {
    closeWorldModal();
    document.getElementById("gameArea")?.scrollIntoView({ behavior: "smooth" });
});

worldModal?.addEventListener("click", event => {
    if (event.target === worldModal) closeWorldModal();
});


// 3. SECRET OBJECTS
const objectStories = {
    mirror: {
        title: "THE MIRROR",
        story: "The mirror reveals memories erased from history. A mysterious voice whispers: The truth is always behind the reflection."
    },
    watch: {
        title: "THE POCKET WATCH",
        story: "This watch stopped at midnight. It remembers the moment the hidden universe disappeared."
    },
    key: {
        title: "THE OLD KEY",
        story: "This key belongs to a door that does not exist in the ordinary world."
    },
    book: {
        title: "THE ANCIENT BOOK",
        story: "The ancient book contains the password to the fifth world. Remember this word: ECHO."
    }
};

let selectedMemory = "";
let discoveredObjects = [];

const modal = document.getElementById("storyModal");

document.querySelectorAll("[data-object]").forEach(button => {
    button.addEventListener("click", () => {
        const objectName = button.dataset.object;
        const object = objectStories[objectName];
        if (!object || !modal) return;

        selectedMemory = objectName;
        document.getElementById("modalTitle").textContent = object.title;
        document.getElementById("modalStory").textContent = object.story;
        modal.style.display = "flex";
    });
});

document.getElementById("chooseObject")?.addEventListener("click", () => {
    if (selectedMemory && !discoveredObjects.includes(selectedMemory)) {
        discoveredObjects.push(selectedMemory);
        updateJournal();
    }
    if (modal) modal.style.display = "none";
});

function updateJournal() {
    const journal = document.getElementById("journalList");

    if (journal) {
        journal.innerHTML = "";

        if (discoveredObjects.length === 0) {
            journal.textContent = "No memories collected yet.";
        } else {
            discoveredObjects.forEach(object => {
                const item = document.createElement("p");
                item.textContent = "✦ " + object.toUpperCase() + " MEMORY DISCOVERED";
                journal.appendChild(item);
            });
        }
    }

    const count = document.getElementById("clueCount");
    if (count) count.textContent = discoveredObjects.length;
}

document.getElementById("closeModal")?.addEventListener("click", () => {
    if (modal) modal.style.display = "none";
});

modal?.addEventListener("click", event => {
    if (event.target === modal) modal.style.display = "none";
});


// 4. PUZZLE ROOM
let puzzleSolved = false;

function checkPuzzle() {
    const answer = document.getElementById("answerInput").value.trim().toLowerCase();
    const message = document.getElementById("puzzleMessage");

    if (answer === "echo") {
        puzzleSolved = true;
        message.textContent = "✦ CORRECT! THE SECRET WORLD IS UNLOCKED.";
        message.style.color = "#9cffbd";
        document.getElementById("secretLocation").classList.remove("hidden");
    } else {
        message.textContent = "Incorrect password. Try again!";
        message.style.color = "#ff9999";
    }
}

document.getElementById("checkAnswer")?.addEventListener("click", checkPuzzle);

document.getElementById("answerInput")?.addEventListener("keydown", event => {
    if (event.key === "Enter") checkPuzzle();
});

document.getElementById("secretExplore")?.addEventListener("click", () => {
    exploreWorld("secret");
});


// 5. DETECTIVE GAME
const missionPanel = document.getElementById("missionPanel");

let gameScore = 0;
let evidenceFound = 0;
let timeLeft = 60;
let gameTimer = null;

const missions = [
    {
        title: "MISSION 01: THE FORGOTTEN LIBRARY",
        image: "05_forgotten_library.jpg",
        story: "You enter an ancient library. Four books are on the table. A note says the year the universe disappeared is hidden in one book.",
        question: "Which book contains the secret year?",
        options: [
            "The Book of Dreams — 1842",
            "The Book of War — 1920",
            "The Book of Kings — 2001",
            "The Book of Stars — 1765"
        ],
        answer: "The Book of Dreams — 1842",
        success: "You found the year 1842! A hidden page reveals the next clue: TIME."
    },
    {
        title: "MISSION 02: THE CLOCKWORK CITY",
        image: "02_floating_world.jpg",
        story: "A giant clock controls the city. Your library clue says the universe disappeared at midnight.",
        question: "What time should you set on the clock?",
        options: ["3:00", "6:30", "12:00", "9:15"],
        answer: "12:00",
        success: "Correct! The clock starts moving and points toward a mysterious mirror."
    },
    {
        title: "MISSION 03: THE MIRROR DIMENSION",
        image: "03_underwater_world.jpg",
        story: "A mirror contains four messages. Only one tells you where the next clue is hidden.",
        question: "Which message should you trust?",
        options: [
            "Forget the past.",
            "Look behind the reflection.",
            "The garden is empty.",
            "Time is meaningless."
        ],
        answer: "Look behind the reflection.",
        success: "You discover a hidden flower symbol. The final world is waiting."
    },
    {
        title: "MISSION 04: THE LOST GARDEN",
        image: "04_desert_world.jpg",
        story: "Four symbols are carved into the garden gate. An inscription says: The moon comes first, the leaf follows, the star shines third, and the flower blooms last.",
        question: "Type the four symbols in the correct order.",
        input: true,
        answer: "moon leaf star flower",
        success: "The gate opens! You have collected all four pieces of evidence."
    }
];

function updateGameStats() {
    document.getElementById("score").textContent = gameScore;
    document.getElementById("evidenceCount").textContent = evidenceFound;
    document.getElementById("progressBar").style.width = (evidenceFound / 4 * 100) + "%";
}

function startInvestigation() {
    clearInterval(gameTimer);

    gameScore = 0;
    evidenceFound = 0;
    timeLeft = 60;

    updateGameStats();
    updateTimer();
    showMission(0);

    gameTimer = setInterval(() => {
        timeLeft--;
        updateTimer();

        if (timeLeft <= 0) {
            clearInterval(gameTimer);
            missionPanel.innerHTML = `
                <h2>TIME IS UP!</h2>
                <p>Your investigation has ended.</p>
                <button class="main-btn" id="playAgain">TRY AGAIN</button>
            `;
        }
    }, 1000);
}

function updateTimer() {
    const minutes = Math.floor(timeLeft / 60);
    const seconds = timeLeft % 60;
    document.getElementById("timer").textContent =
        String(minutes).padStart(2, "0") + ":" + String(seconds).padStart(2, "0");
}

function showMission(index) {
    const mission = missions[index];

    missionPanel.innerHTML = `
        <p class="eyebrow">INVESTIGATION ${index + 1} OF 4</p>
        <h2>${mission.title}</h2>

        <img class="mission-image" src="${mission.image}" alt="Mission location">

        <p>${mission.story}</p>
        <h3>${mission.question}</h3>

        ${mission.input ? `
            <input class="mission-input" id="gardenAnswer" placeholder="moon leaf star flower">
            <button class="main-btn" id="checkGarden">UNLOCK THE GATE</button>
        ` : `
            <div class="mission-options">
                ${mission.options.map(option => `
                    <button data-answer="${option}">${option}</button>
                `).join("")}
            </div>
        `}

        <p class="mission-feedback" id="missionFeedback"></p>
    `;
}

function checkMissionAnswer(answer) {
    const mission = missions[evidenceFound];
    const feedback = document.getElementById("missionFeedback");
    const cleanAnswer = answer.trim().toLowerCase();

    if (cleanAnswer === mission.answer.toLowerCase()) {
        evidenceFound++;
        gameScore += 100;
        updateGameStats();

        missionPanel.innerHTML = `
            <h2>✦ EVIDENCE COLLECTED!</h2>
            <p>${mission.success}</p>
            <p>+100 points</p>
            <button class="main-btn" id="nextMission">
                ${evidenceFound === 4 ? "FINAL INVESTIGATION →" : "NEXT MISSION →"}
            </button>
        `;
    } else {
        gameScore = Math.max(0, gameScore - 10);
        updateGameStats();
        feedback.textContent = "Incorrect! Study the clue and try again.";
        feedback.style.color = "#ff9999";
    }
}

function showFinalInvestigation() {
    missionPanel.innerHTML = `
        <p class="eyebrow">FINAL CASE FILE</p>
        <h2>WHO MADE THE UNIVERSE DISAPPEAR?</h2>
        <p>You collected all four pieces of evidence. Now choose your suspect.</p>

        <div class="mission-options">
            <button data-suspect="clockmaker">🕰️ The Clockmaker</button>
            <button data-suspect="gardener">🌿 The Gardener</button>
            <button data-suspect="librarian">📚 The Librarian</button>
        </div>

        <p class="mission-feedback" id="suspectFeedback"></p>
    `;
}

function finishGame() {
    clearInterval(gameTimer);

    missionPanel.innerHTML = `
        <h2>🏆 CASE SOLVED!</h2>
        <p>The Clockmaker made the universe disappear to protect it from destruction.</p>
        <h2>FINAL SCORE: ${gameScore}</h2>
        <p>Evidence collected: ${evidenceFound}/4</p>
        <p>You are officially a Master Detective!</p>
        <button class="main-btn" id="playAgain">PLAY AGAIN</button>
    `;
}

// All game clicks are handled here.
missionPanel?.addEventListener("click", event => {
    const answerButton = event.target.closest("[data-answer]");
    const suspectButton = event.target.closest("[data-suspect]");

    if (answerButton) checkMissionAnswer(answerButton.dataset.answer);

    if (event.target.id === "checkGarden") {
        const answer = document.getElementById("gardenAnswer").value
            .toLowerCase()
            .replace(/[^a-z ]/g, " ")
            .replace(/\s+/g, " ")
            .trim();
        checkMissionAnswer(answer);
    }

    if (event.target.id === "nextMission") {
        if (evidenceFound < 4) showMission(evidenceFound);
        else showFinalInvestigation();
    }

    if (suspectButton) {
        if (suspectButton.dataset.suspect === "clockmaker") {
            gameScore += 200;
            updateGameStats();
            finishGame();
        } else {
            document.getElementById("suspectFeedback").textContent =
                "That suspect doesn't match all the evidence. Try again!";
        }
    }

    if (event.target.id === "playAgain") startInvestigation();
});

document.getElementById("startGame")?.addEventListener("click", startInvestigation);

// Enter key for garden puzzle
missionPanel?.addEventListener("keydown", event => {
    if (event.key === "Enter" && event.target.id === "gardenAnswer") {
        checkMissionAnswer(event.target.value);
    }
});


// 6. FINAL REVELATION
const endings = {
    restore: {
        title: "THE GUARDIAN OF WORLDS",
        image: "12_ending_guardian.jpg",
        story: "You restored the universe. The four memories unite and the forgotten worlds return."
    },
    protect: {
        title: "THE TRUTH SEEKER",
        image: "11_ending_truth.jpg",
        story: "You protected the secrets. The universe remains hidden, but its memories are safe."
    },
    leave: {
        title: "THE LOST SEEKER",
        image: "13_ending_final.jpg",
        story: "You left everything behind. The portal closes, but the secrets remain."
    }
};

document.querySelectorAll("[data-choice]").forEach(button => {
    button.addEventListener("click", () => {
        const ending = endings[button.dataset.choice];

        document.getElementById("endingImage").src = ending.image;
        document.getElementById("endingTitle").textContent = ending.title;
        document.getElementById("endingText").textContent = ending.story;
        document.getElementById("choiceMessage").textContent = "Your decision has shaped your ending.";
        document.querySelector(".choice-container").classList.add("hidden");
    });
});


// 7. RESTART THE WEBSITE
document.getElementById("restartBtn")?.addEventListener("click", () => {
    clearInterval(gameTimer);

    gameScore = 0;
    evidenceFound = 0;
    timeLeft = 60;
    discoveredWorlds = [];
    discoveredObjects = [];
    selectedMemory = "";
    puzzleSolved = false;

    updateJournal();
    updateGameStats();
    updateTimer();

    document.getElementById("answerInput").value = "";
    document.getElementById("puzzleMessage").textContent = "";
    document.getElementById("secretLocation").classList.add("hidden");
    document.getElementById("worldMessage").textContent = "Select a location to discover its secret.";

    if (modal) modal.style.display = "none";
    closeWorldModal();

    document.getElementById("endingImage").src = "11_ending_truth.jpg";
    document.getElementById("endingTitle").textContent = "The Truth Awaits";
    document.getElementById("endingText").textContent =
        "Four objects. Four worlds. One forgotten universe.";
    document.getElementById("choiceMessage").textContent = "";
    document.querySelector(".choice-container").classList.remove("hidden");

    missionPanel.innerHTML = `
        <h2>CASE 001: THE MISSING UNIVERSE</h2>
        <p>Four worlds have disappeared. Investigate them, collect evidence and discover the truth.</p>
        <button id="startGame" class="main-btn">START INVESTIGATION →</button>
    `;

    // Reconnect the new start button after resetting.
    document.getElementById("startGame").addEventListener("click", startInvestigation);

    showPage("home");
});


// INITIAL SETUP
updateJournal();
updateGameStats();
updateTimer();