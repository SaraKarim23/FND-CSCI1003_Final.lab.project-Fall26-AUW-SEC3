let totalXP = 0;


function addXP(points) {
    totalXP += points;

    document.getElementById("xp").innerHTML = totalXP;

    let currentLevel = Math.floor(totalXP / 100) + 1;

    document.getElementById("level").innerHTML = currentLevel;
}
function createNewSubject() {
    const nameInput = document.getElementById('subject-name');
    const descInput = document.getElementById('subject-desc');
    
    const name = nameInput.value.trim();
    const desc = descInput.value.trim();

    if (name === "") {
        alert("لطفاً نام مضمون را وارد کنید!");
        return;
    }

    const grid = document.querySelector('.course-grid');
    
    // ساخت کارت جدید
    const newCard = document.createElement('div');
    newCard.className = 'course-card';
    newCard.innerHTML = `
        <p style="font-size: 13px; color: #a78bfa; margin-bottom: 8px;">🆕 0 Cards</p>
        <h3>${name}</h3>
        <p>${desc || 'Custom flashcard subject.'}</p>
        <p style="margin-top: 15px; color: white; font-size: 14px;">Progress: 0% <strong>Study Now →</strong></p>
    `;

    // اضافه کردن کارت به صفحه
    grid.appendChild(newCard);

    // پاک کردن فرم و بستن پنجره
    nameInput.value = "";
    descInput.value = "";
    window.location.hash = ""; 
}
    // تابع کمکی برای ساختن کارت مضمون روی صفحه Courses
function renderCourseCard(name, desc) {
    const grid = document.querySelector('.course-grid');
    if (!grid) return;

    const newCard = document.createElement('div');
    newCard.className = 'course-card';
    newCard.style.cursor = 'pointer';

    newCard.addEventListener('click', function() {
        openCourse(name);
    });

    newCard.innerHTML = `
        <button type="button" class="delete-card-btn" onclick="deleteSubject(event, this)" title="Delete Subject">🗑️</button>
        <p style="font-size: 13px; color: #a78bfa; margin-bottom: 8px;">🆕 0 Cards</p>
        <h3>${name}</h3>
        <p>${desc || 'Custom flashcard subject.'}</p>
        <p style="margin-top: 15px; color: white; font-size: 14px;">Progress: 0% <strong>Study Now →</strong></p>
    `;

    grid.appendChild(newCard);
}

// ساخت مضمون جدید و ذخیره دائمی در حافظه مرورگر (localStorage)
function createNewSubject() {
    const nameInput = document.getElementById('subject-name');
    const descInput = document.getElementById('subject-desc');
    
    const name = nameInput.value.trim();
    const desc = descInput.value.trim();

    if (name === "") {
        alert("Please enter a subject name!");
        return;
    }

    // ذخیره در حافظه مشترک تا هم در Courses بماند و هم در My Results نشان داده شود
    let savedCourses = JSON.parse(localStorage.getItem('flashmaster_courses')) || [];
    savedCourses.push({ name: name, desc: desc || 'Custom flashcard subject.' });
    localStorage.setItem('flashmaster_courses', JSON.stringify(savedCourses));

    // نمایش روی صفحه
    renderCourseCard(name, desc);

    nameInput.value = "";
    descInput.value = "";
    window.location.hash = "";
}

// تابع حذف کردن مضمون (هم از صفحه و هم از حافظه مرورگر)
function deleteSubject(event, button) {
    event.stopPropagation();
    
    if (confirm("Are you sure you want to delete this subject?")) {
        const card = button.closest('.course-card');
        const subjectTitle = card.querySelector('h3')?.textContent.trim();

        if (subjectTitle) {
            let savedCourses = JSON.parse(localStorage.getItem('flashmaster_courses')) || [];
            savedCourses = savedCourses.filter(c => (typeof c === 'string' ? c : c.name) !== subjectTitle);
            localStorage.setItem('flashmaster_courses', JSON.stringify(savedCourses));
        }

        card.remove();
    }
}

// بارگذاری خودکار مضمون‌های اضافه‌شده هنگام باز شدن صفحه Courses
window.addEventListener('DOMContentLoaded', () => {
    const savedCourses = JSON.parse(localStorage.getItem('flashmaster_courses')) || [];
    savedCourses.forEach(course => {
        const name = typeof course === 'string' ? course : course.name;
        const desc = typeof course === 'string' ? 'Custom flashcard subject.' : course.desc;
        renderCourseCard(name, desc);
    });
});
// ================= PROFILE PAGE FUNCTIONS =================

let selectedAvatarIcon = localStorage.getItem('flashmaster_avatar') || "🧑‍🎓";

// بارگذاری خودکار اطلاعات پروفایل (نام، استیکر و دکمه فعال) هنگام ورود به صفحه Profile
function loadProfilePageData() {
    const savedName = localStorage.getItem('flashmaster_username') || "Halima";
    const savedAvatar = localStorage.getItem('flashmaster_avatar') || "🧑‍🎓";
    selectedAvatarIcon = savedAvatar;

    const currentAvatarEl = document.getElementById('current-avatar');
    const displayNameEl = document.getElementById('profile-display-name');
    const inputNameEl = document.getElementById('input-username');
    const headerUserEl = document.getElementById('header-username') || document.querySelector('.main-content .user');

    if (currentAvatarEl) currentAvatarEl.textContent = savedAvatar;
    if (displayNameEl) displayNameEl.textContent = savedName;
    if (inputNameEl) inputNameEl.value = savedName;
    if (headerUserEl) headerUserEl.textContent = `${savedAvatar} ${savedName}`;

    // روشن کردن استیکر انتخاب‌شده فعلی در لیست استیکرها
    document.querySelectorAll('.avatar-btn').forEach(btn => {
        if (btn.textContent.trim() === savedAvatar) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });
}

function selectAvatar(button, icon) {
    selectedAvatarIcon = icon;
    const currentAvatarEl = document.getElementById('current-avatar');
    if (currentAvatarEl) currentAvatarEl.textContent = icon;
    
    // حذف حالت فعال از بقیه دکمه‌ها و فعال کردن استیکر انتخابی
    document.querySelectorAll('.avatar-btn').forEach(btn => btn.classList.remove('active'));
    if (button) button.classList.add('active');
}

function saveProfileSettings() {
    const inputEl = document.getElementById('input-username');
    const newName = inputEl ? inputEl.value.trim() : "";
    if (newName === "") {
        alert("Display name cannot be empty!");
        return;
    }

    // ذخیره در حافظه مرورگر (LocalStorage)
    localStorage.setItem('flashmaster_username', newName);
    localStorage.setItem('flashmaster_avatar', selectedAvatarIcon);

    // به‌روزرسانی فوری نام و استیکر در کارت پروفایل و هدر تمام صفحات
    const displayNameEl = document.getElementById('profile-display-name');
    if (displayNameEl) displayNameEl.textContent = newName;

    const headerUserEl = document.getElementById('header-username') || document.querySelector('.main-content .user');
    if (headerUserEl) headerUserEl.textContent = `${selectedAvatarIcon} ${newName}`;

    alert("Profile settings saved successfully!");
}

// اجرای خودکار هم در زمان باز شدن اولیه و هم هنگام جابه‌جایی بین صفحات (SPA)
document.addEventListener('DOMContentLoaded', loadProfilePageData);
// ================= HOME PAGE TO COURSES CONNECTION =================

// تابع دکمه Start Learning در صفحه اصلی
function startLearning() {
    const lastCourse = localStorage.getItem('flashmaster_last_course');
    
    if (lastCourse) {
        // اگر قبلاً درسی را خوانده بود، مستقیم به ادامه همان درس برود
        window.location.href = `courses.html?course=${encodeURIComponent(lastCourse)}`;
    } else {
        // اگر هنوز درسی را شروع نکرده، وارد صفحه همه کورس‌ها شود
        window.location.href = 'courses.html';
    }
}

// تابع کلیک روی کارت‌های مضمون (هم در Home و هم در Courses)
function openCourse(courseName) {
    // ذخیره نام آخرین مضمون انتخاب‌شده در حافظه مرورگر
    localStorage.setItem('flashmaster_last_course', courseName);
    
    // انتقال به صفحه کورس‌ها همراه با نام مضمون انتخاب‌شده
    window.location.href = `flashcards.html?course=${encodeURIComponent(courseName)}`;
}


// بررسی خودکار هنگام باز شدن صفحه courses.html
window.addEventListener('DOMContentLoaded', () => {
    // تغییر متن دکمه Start Learning در صفحه Home اگر کاربر درس ناتمام داشته باشد
    const lastCourse = localStorage.getItem('flashmaster_last_course');
    const startBtn = document.querySelector('.hero button');
    if (startBtn && lastCourse) {
        startBtn.textContent = `Continue ${lastCourse} →`;
    }

    
    // اگر در صفحه courses.html هستیم و در آدرس نام درسی فرستاده شده بود
    const urlParams = new URLSearchParams(window.location.search);
    const selectedCourse = urlParams.get('course');
    if (selectedCourse && window.location.pathname.includes('courses.html')) {
        console.log("Resuming course:", selectedCourse);
    }
});

// ================= 1. REAL-TIME COURSE CARD COUNTS & PROGRESS =================
function updateCourseCardStats() {
    const courseCards = document.querySelectorAll('.course-card');
    if (courseCards.length === 0) return;

    const storedCards = JSON.parse(localStorage.getItem('flashcards_data')) || [];

    courseCards.forEach(card => {
        const titleEl = card.querySelector('h3');
        if (!titleEl) return;

        const subjectName = titleEl.textContent.trim().toLowerCase();
        const count = storedCards.filter(c => (c.subject || '').trim().toLowerCase() === subjectName).length;
        const percent = Math.min(100, count * 10);

        const badgeEl = card.querySelector('.card-badge');
        if (badgeEl) badgeEl.textContent = `${count} Cards`;

        const footerSpan = card.querySelector('.card-footer span:first-child');
        if (footerSpan) footerSpan.textContent = `Progress: ${percent}%`;
    });
}
// ================= 2. EXACT DYNAMIC STATS FOR HOME, RESULTS & PROFILE =================
function updateResultsAndProfileStats() {
    const path = window.location.pathname.toLowerCase();
    const isHomePage = path.includes('test.html') || path.endsWith('/') || path.includes('index.html');
    const isResultsPage = path.includes('results.html');
    const isProfilePage = path.includes('profile.html');
    if (!isHomePage && !isResultsPage && !isProfilePage) return;

    // خواندن کلیدهای واقعی پروژه شما
    const storedCards = JSON.parse(localStorage.getItem('flashcards_data')) || [];
    const defaultSubjects = ['Biology', 'English', 'Mathematics', 'Computer Science'];
    const savedCourses = JSON.parse(localStorage.getItem('flashmaster_courses')) || [];

    // ساخت لیست یکتای تمام مضمون‌های فعلی و آینده شما
    const validSubjects = new Set(defaultSubjects.map(s => s.toLowerCase()));
    savedCourses.forEach(course => {
        const name = typeof course === 'string' ? course : (course.name || course.title || '');
        if (name.trim()) validSubjects.add(name.trim().toLowerCase());
    });

    // شمارش کارت‌های واقعی مربوط به مضمون‌های موجود
    const subjectCounts = {};
    validSubjects.forEach(sub => subjectCounts[sub] = 0);

    storedCards.forEach(card => {
        const sub = (card.subject || '').trim().toLowerCase();
        if (validSubjects.has(sub)) {
            subjectCounts[sub] = (subjectCounts[sub] || 0) + 1;
        }
    });

    const totalCards = Object.values(subjectCounts).reduce((sum, n) => sum + n, 0);
    const completedSubjects = Object.values(subjectCounts).filter(c => c >= 10).length;

    // محاسبه آمار بازی‌های گروهی (Multiplayer)
    const mpHistory = JSON.parse(localStorage.getItem('flashmaster_results')) || [];
    const totalGames = mpHistory.length;
    const currentUser = (localStorage.getItem('flashmaster_username') || 'Player').trim().toLowerCase();

    let wins = 0;
    let totalCorrect = 0;
    let totalQuestions = 0;

    mpHistory.forEach(match => {
        if (match.winner && match.winner.trim().toLowerCase() === currentUser) wins++;
        if (Array.isArray(match.players) && match.players.length > 0) {
            const me = match.players.find(p => p.name && p.name.trim().toLowerCase() === currentUser) || match.players[0];
            totalCorrect += (me.correct || 0);
            totalQuestions += (match.totalQuestions || 0);
        }
    });

    const winRate = totalGames > 0 ? Math.round((wins / totalGames) * 100) : 0;
    const accuracy = totalQuestions > 0 ? Math.round((totalCorrect / totalQuestions) * 100) : 0;
    const streakDays = (totalCards > 0 || totalGames > 0) ? 1 : 0;
    const totalXP = (totalCards * 20) + (totalGames * 50);
    const level = Math.floor(totalXP / 1000) + 1;

    // 1. به‌روزرسانی آمار بالای صفحه خانه (Test.html) با IDهای مستقیم
    if (isHomePage) {
        const xpEl = document.getElementById('xp');
        const levelEl = document.getElementById('level');
        const streakEl = document.getElementById('home-streak');
        const accEl = document.getElementById('home-accuracy');

        if (xpEl) xpEl.textContent = totalXP;
        if (levelEl) levelEl.textContent = level;
        if (streakEl) streakEl.textContent = `${streakDays} Days`;
        if (accEl) accEl.textContent = `${accuracy}%`;
    }

    // 2. به‌روزرسانی مستقیم صفحه My Results
    if (isResultsPage) {
        const cardsEl = document.getElementById('total-cards-reviewed');
        const streakEl = document.getElementById('study-streak');
        const accEl = document.getElementById('overall-accuracy');

        if (cardsEl) cardsEl.textContent = totalCards;
        if (streakEl) streakEl.textContent = `${streakDays} Days`;
        if (accEl) accEl.textContent = `${accuracy}%`;
    }

    // 3. به‌روزرسانی مستقیم صفحه Profile
    if (isProfilePage) {
        document.querySelectorAll('h1, h2, h3, p, span, div, strong').forEach(el => {
            const txt = el.textContent.trim();
            if (el.children.length === 0) {
                if (txt === '87') el.textContent = totalCards;
                if (txt === '5 Days') el.textContent = `${streakDays} Days`;
                if (txt === '2 Subjects') el.textContent = `${completedSubjects} ${completedSubjects === 1 ? 'Subject' : 'Subjects'}`;
                if (txt === '68%') el.textContent = `${winRate}%`;
            }
            if (txt.includes('/ 1,000 XP') && txt.length < 45) {
                const currentLevelXP = totalXP % 1000;
                el.textContent = `${currentLevelXP} / 1,000 XP to Level ${level + 1}`;

                const barContainer = el.previousElementSibling || (el.parentElement && el.parentElement.querySelector('div'));
                if (barContainer && barContainer.firstElementChild) {
                    barContainer.firstElementChild.style.width = `${(currentLevelXP / 1000) * 100}%`;
                }
            }
        });
    }
}



// ================= 4. CONTINUOUS MULTI-TRACK STUDY MUSIC PLAYER (MODERN PRO) =================
function initStudyMusicPlayer() {
    if (document.getElementById('study-music-widget')) return;

    const playlist = [
        { name: '🎹 Piano Background', file: 'Music1.mp3' },
        { name: '🎧 Lo-Fi Study Session', file: 'Music2.mp3' },
        { name: '🎼 Stride Piano Study', file: 'Music3.mp3' },
        { name: '🌊 Headway Audio Track', file: 'Music4.mp3' },
        { name: '🏔️ Mountain Lo-Fi Study', file: 'Music5.mp3' }
    ];

    // تزریق انیمیشن‌های اختصاصی اکولایزر و دیسک چرخان
    if (!document.getElementById('study-music-pro-styles')) {
        const styleTag = document.createElement('style');
        styleTag.id = 'study-music-pro-styles';
        styleTag.textContent = `
            @keyframes spinMusicDisc {
                from { transform: rotate(0deg); }
                to { transform: rotate(360deg); }
            }
            @keyframes eqBarBounce {
                0%, 100% { height: 3px; }
                50% { height: 13px; }
            }
            #study-music-widget {
                position: fixed;
                bottom: 16px;
                left: 14px;
                width: 215px;
                box-sizing: border-box;
                z-index: 9999;
                display: flex;
                flex-wrap: wrap;
                align-items: center;
                justify-content: space-between;
                gap: 9px;
                background: linear-gradient(145deg, rgba(22, 27, 56, 0.96), rgba(38, 28, 74, 0.96));
                border: 1.5px solid rgba(139, 92, 246, 0.45);
                backdrop-filter: blur(14px);
                -webkit-backdrop-filter: blur(14px);
                padding: 12px 13px;
                border-radius: 18px;
                box-shadow: 0 12px 28px rgba(0, 0, 0, 0.5), 0 0 16px rgba(139, 92, 246, 0.22);
                color: #f8fafc;
                font-family: inherit;
                transition: all 0.3s ease;
            }
            #study-music-widget:hover {
                transform: translateY(-2px);
                box-shadow: 0 15px 32px rgba(0, 0, 0, 0.55), 0 0 22px rgba(139, 92, 246, 0.38);
            }
            #study-music-widget.is-playing {
                border-color: #a78bfa;
            }
            .sm-disc-badge {
                width: 34px;
                height: 34px;
                border-radius: 50%;
                background: linear-gradient(135deg, #6366f1, #a855f7);
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 17px;
                box-shadow: 0 4px 10px rgba(139, 92, 246, 0.45);
                flex-shrink: 0;
            }
            #study-music-widget.is-playing .sm-disc-badge {
                animation: spinMusicDisc 5s linear infinite;
            }
            .sm-info-col {
                display: flex;
                flex-direction: column;
                gap: 6px;
                flex: 1;
                min-width: 135px;
            }
            .sm-top-status {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 6px;
                font-size: 10.5px;
                font-weight: 700;
                letter-spacing: 0.3px;
                color: #c4b5fd;
            }
            .sm-eq-bars {
                display: inline-flex;
                align-items: flex-end;
                gap: 2px;
                height: 13px;
            }
            .sm-eq-bars span {
                width: 2.5px;
                height: 3px;
                border-radius: 2px;
                background: #38bdf8;
                transition: height 0.2s;
            }
            #study-music-widget.is-playing .sm-eq-bars span:nth-child(1) {
                animation: eqBarBounce 0.7s ease-in-out infinite;
                background: #38bdf8;
            }
            #study-music-widget.is-playing .sm-eq-bars span:nth-child(2) {
                animation: eqBarBounce 0.5s ease-in-out infinite 0.15s;
                background: #a855f7;
            }
            #study-music-widget.is-playing .sm-eq-bars span:nth-child(3) {
                animation: eqBarBounce 0.8s ease-in-out infinite 0.3s;
                background: #f472b6;
            }
            #study-music-widget.is-playing .sm-eq-bars span:nth-child(4) {
                animation: eqBarBounce 0.6s ease-in-out infinite 0.1s;
                background: #34d399;
            }
            .sm-track-select {
                width: 100%;
                background: rgba(15, 23, 42, 0.8);
                color: #ffffff;
                border: 1px solid rgba(167, 139, 250, 0.35);
                border-radius: 9px;
                padding: 5px 8px;
                font-size: 11.5px;
                font-weight: 600;
                outline: none;
                cursor: pointer;
                transition: 0.2s;
            }
            .sm-track-select:hover {
                border-color: #c084fc;
            }
            .sm-controls-row {
                width: 100%;
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 6px;
                padding-top: 4px;
                border-top: 1px solid rgba(255, 255, 255, 0.08);
            }
            .sm-circle-btn {
                width: 30px;
                height: 30px;
                border-radius: 50%;
                border: none;
                background: linear-gradient(135deg, #7c3aed, #4f46e5);
                color: #ffffff;
                font-size: 13px;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                box-shadow: 0 3px 8px rgba(124, 58, 237, 0.4);
                transition: 0.2s;
                flex-shrink: 0;
            }
            .sm-circle-btn:hover {
                transform: scale(1.08);
            }
            .sm-next-btn {
                width: 28px;
                height: 28px;
                border-radius: 50%;
                border: 1px solid rgba(167, 139, 250, 0.35);
                background: rgba(255, 255, 255, 0.08);
                color: #e2e8f0;
                font-size: 11px;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                transition: 0.2s;
                flex-shrink: 0;
            }
            .sm-next-btn:hover {
                background: rgba(167, 139, 250, 0.25);
                color: #ffffff;
            }
            .sm-vol-wrap {
                display: flex;
                align-items: center;
                gap: 5px;
                background: rgba(15, 23, 42, 0.55);
                padding: 4px 8px;
                border-radius: 10px;
                border: 1px solid rgba(255, 255, 255, 0.08);
                flex: 1;
            }
            .sm-vol-slider {
                width: 100%;
                min-width: 55px;
                accent-color: #a855f7;
                cursor: pointer;
            }
        `;
        document.head.appendChild(styleTag);
    }

    const widget = document.createElement('div');
    widget.id = 'study-music-widget';

    // 1. دیسک چرخان موسیقی
    const discBadge = document.createElement('div');
    discBadge.className = 'sm-disc-badge';
    discBadge.textContent = '🎧';

    // 2. ستون اطلاعات (وضعیت + اکولایزر + منوی انتخاب آهنگ)
    const infoCol = document.createElement('div');
    infoCol.className = 'sm-info-col';

    const topStatus = document.createElement('div');
    topStatus.className = 'sm-top-status';

    const statusLabel = document.createElement('span');
    statusLabel.textContent = '✨ STUDY RADIO';

    const eqBars = document.createElement('div');
    eqBars.className = 'sm-eq-bars';
    eqBars.innerHTML = '<span></span><span></span><span></span><span></span>';

    topStatus.appendChild(statusLabel);
    topStatus.appendChild(eqBars);

    const trackSelect = document.createElement('select');
    trackSelect.className = 'sm-track-select';
    playlist.forEach((track, idx) => {
        const opt = document.createElement('option');
        opt.value = idx;
        opt.textContent = track.name;
        opt.style.background = '#1e203c';
        trackSelect.appendChild(opt);
    });

    infoCol.appendChild(topStatus);
    infoCol.appendChild(trackSelect);

    // 3. دکمه‌های کنترل (Play/Pause + Next + Volume)
    const controlsRow = document.createElement('div');
    controlsRow.className = 'sm-controls-row';

    const toggleBtn = document.createElement('button');
    toggleBtn.type = 'button';
    toggleBtn.className = 'sm-circle-btn';
    toggleBtn.title = 'Play / Pause Music';

    const nextBtn = document.createElement('button');
    nextBtn.type = 'button';
    nextBtn.className = 'sm-next-btn';
    nextBtn.textContent = '⏭';
    nextBtn.title = 'Next Track';

    const volWrap = document.createElement('div');
    volWrap.className = 'sm-vol-wrap';

    const volIcon = document.createElement('span');
    volIcon.style.fontSize = '13px';
    volIcon.textContent = '🔊';

    const volSlider = document.createElement('input');
    volSlider.type = 'range';
    volSlider.className = 'sm-vol-slider';
    volSlider.min = '0';
    volSlider.max = '1';
    volSlider.step = '0.05';

    volWrap.appendChild(volIcon);
    volWrap.appendChild(volSlider);

    controlsRow.appendChild(toggleBtn);
    controlsRow.appendChild(nextBtn);
    controlsRow.appendChild(volWrap);

    widget.appendChild(discBadge);
    widget.appendChild(infoCol);
    widget.appendChild(controlsRow);
    document.body.appendChild(widget);

    // بازیابی وضعیت پخش از حافظه
    let currentIndex = parseInt(localStorage.getItem('flashmaster_track_index') || '0', 10);
    if (isNaN(currentIndex) || currentIndex < 0 || currentIndex >= playlist.length) currentIndex = 0;
    trackSelect.value = currentIndex;

    const audio = new Audio(playlist[currentIndex].file);
    audio.loop = true;

    const savedVol = localStorage.getItem('flashmaster_music_vol');
    audio.volume = savedVol !== null ? parseFloat(savedVol) : 0.35;
    volSlider.value = audio.volume;
    volIcon.textContent = audio.volume === 0 ? '🔇' : (audio.volume < 0.5 ? '🔉' : '🔊');

    const savedTime = parseFloat(localStorage.getItem('flashmaster_music_time') || '0');
    if (!isNaN(savedTime) && savedTime > 0) {
        audio.currentTime = savedTime;
    }

    let isPlaying = localStorage.getItem('flashmaster_music_playing') === 'true';

    function updateUI() {
        toggleBtn.textContent = isPlaying ? '⏸' : '▶';
        statusLabel.textContent = isPlaying ? '🎵 PLAYING NOW' : '💤 PAUSED';
        widget.classList.toggle('is-playing', isPlaying);
    }
    updateUI();

    setInterval(() => {
        if (!audio.paused) {
            localStorage.setItem('flashmaster_music_time', audio.currentTime);
        }
    }, 500);

    if (isPlaying) {
        audio.play().catch(() => {
            const resumeOnFirstClick = () => {
                if (localStorage.getItem('flashmaster_music_playing') === 'true') {
                    audio.play().then(() => {
                        isPlaying = true;
                        updateUI();
                    }).catch(() => {});
                }
                document.removeEventListener('click', resumeOnFirstClick);
            };
            document.addEventListener('click', resumeOnFirstClick);
        });
    }

    // پخش یا توقف
    toggleBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (audio.paused) {
            audio.play().then(() => {
                isPlaying = true;
                localStorage.setItem('flashmaster_music_playing', 'true');
                updateUI();
            }).catch(() => {
                alert(`فایل ${playlist[currentIndex].file} پیدا نشد!`);
            });
        } else {
            audio.pause();
            isPlaying = false;
            localStorage.setItem('flashmaster_music_playing', 'false');
            updateUI();
        }
    });

    // تغییر آهنگ با تابع مشترک
    function switchTrack(newIdx) {
        currentIndex = newIdx;
        trackSelect.value = currentIndex;
        localStorage.setItem('flashmaster_track_index', currentIndex);
        localStorage.setItem('flashmaster_music_time', '0');

        audio.src = playlist[currentIndex].file;
        audio.currentTime = 0;
        audio.play().then(() => {
            isPlaying = true;
            localStorage.setItem('flashmaster_music_playing', 'true');
            updateUI();
        }).catch(() => {
            alert(`فایل ${playlist[currentIndex].file} پیدا نشد!`);
        });
    }

    trackSelect.addEventListener('click', (e) => e.stopPropagation());
    trackSelect.addEventListener('change', () => {
        switchTrack(parseInt(trackSelect.value, 10));
    });

    nextBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        switchTrack((currentIndex + 1) % playlist.length);
    });

    // تنظیم صدا
    volSlider.addEventListener('click', (e) => e.stopPropagation());
    volSlider.addEventListener('input', () => {
        audio.volume = parseFloat(volSlider.value);
        volIcon.textContent = audio.volume === 0 ? '🔇' : (audio.volume < 0.5 ? '🔉' : '🔊');
        localStorage.setItem('flashmaster_music_vol', volSlider.value);
    });
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initStudyMusicPlayer);
} else {
    initStudyMusicPlayer();
}
// ================= MASTER SUBMISSION CONTROLLER (100% STABLE) =================
document.addEventListener('DOMContentLoaded', () => {
    const savedName = localStorage.getItem('flashmaster_username') || 'Halima';
    const savedAvatar = localStorage.getItem('flashmaster_avatar') || '🦊';
    const storedCards = JSON.parse(localStorage.getItem('flashcards_data')) || [];
    const mpHistory = JSON.parse(localStorage.getItem('flashmaster_results')) || [];
    const studyStats = JSON.parse(localStorage.getItem('flashmaster_study_stats')) || {};

    // 1. نام و استیکر واقعی کاربر در هدر تمام صفحات
    const headerUser = document.getElementById('header-username') || document.querySelector('.main-content .user');
    if (headerUser) headerUser.textContent = `${savedAvatar} ${savedName}`;

    // 2. واقعی کردن تمام آمارهای صفحه Profile (حذف عدد فیک 87 و نمایش آمار واقعی)
    if (window.location.pathname.toLowerCase().includes('profile.html')) {
        const displayName = document.getElementById('profile-display-name') || document.querySelector('.profile-info h2, .profile-card h2');
        const avatarBig = document.getElementById('current-avatar') || document.querySelector('.profile-avatar, .avatar-circle');
        if (displayName) displayName.textContent = savedName;
        if (avatarBig) avatarBig.textContent = savedAvatar;

        // جایگزینی عدد فیک 87 با تعداد واقعی کارت‌های مطالعه/ساخته‌شده
        document.querySelectorAll('.stat-card h3, .stat-card .stat-value, .profile-stats h2, .profile-stats h3').forEach(el => {
            if (el.textContent.trim() === '87') {
                el.textContent = storedCards.length;
            }
        });

        // فعال‌سازی کامل انتخاب استیکرها و ذخیره نام در پایین صفحه Profile
        const inputName = document.getElementById('input-username') || document.querySelector('input[type="text"]');
        if (inputName) inputName.value = savedName;

        let chosenIcon = savedAvatar;
        const avatarBtns = document.querySelectorAll('.avatar-btn');
        avatarBtns.forEach(btn => {
            const icon = btn.textContent.trim();
            btn.classList.toggle('active', icon === savedAvatar);
            btn.onclick = (e) => {
                e.preventDefault();
                chosenIcon = icon;
                if (avatarBig) avatarBig.textContent = icon;
                avatarBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
            };
        });

        window.selectAvatar = (btn, icon) => {
            chosenIcon = icon;
            if (avatarBig) avatarBig.textContent = icon;
            avatarBtns.forEach(b => b.classList.remove('active'));
            if (btn) btn.classList.add('active');
        };

        window.saveProfileSettings = () => {
            const newName = inputName ? inputName.value.trim() : '';
            if (!newName) return alert('Please enter a display name!');
            localStorage.setItem('flashmaster_username', newName);
            localStorage.setItem('flashmaster_avatar', chosenIcon);
            if (displayName) displayName.textContent = newName;
            if (headerUser) headerUser.textContent = `${chosenIcon} ${newName}`;
            alert('Profile updated successfully!');
        };
    }

    // 3. واقعی کردن تعداد کارت‌ها در کارت‌های صفحه Courses (جایگزینی 24, 18, 30, 15 با تعداد واقعی)
    if (window.location.pathname.toLowerCase().includes('courses.html')) {
        document.querySelectorAll('.course-card').forEach(card => {
            const titleEl = card.querySelector('h3');
            const firstP = card.querySelector('p');
            if (titleEl && firstP) {
                const subName = titleEl.textContent.trim().toLowerCase();
                const count = storedCards.filter(c => (c.subject || '').toLowerCase() === subName).length;
                const iconMatch = firstP.textContent.trim().split(' ')[0] || '📘';
                firstP.textContent = `${iconMatch} ${count} Cards`;
            }
        });
    }

    // 4. ادامه پخش موسیقی هنگام جابه‌جایی بین صفحات (بدون نیاز به SPA ناپایدار)
    const audio = document.getElementById('bg-music') || document.querySelector('audio');
    if (audio) {
        const savedTrack = localStorage.getItem('fm_music_src');
        const savedTime = parseFloat(localStorage.getItem('fm_music_time') || '0');
        const wasPlaying = localStorage.getItem('fm_music_playing') === 'true';

        if (savedTrack && audio.src !== savedTrack) audio.src = savedTrack;
        if (!isNaN(savedTime) && savedTime > 0) audio.currentTime = savedTime;
        if (wasPlaying) audio.play().catch(() => {});

        setInterval(() => {
            if (audio.src) localStorage.setItem('fm_music_src', audio.src);
            localStorage.setItem('fm_music_time', String(audio.currentTime || 0));
            localStorage.setItem('fm_music_playing', String(!audio.paused));
        }, 500);
    }

    // 5. تابع قطعی حذف مضمون‌ها
    window.deleteSubject = (event, button) => {
        if (event) event.stopPropagation();
        if (!confirm('Are you sure you want to delete this subject?')) return;
        const card = button.closest('.course-card');
        if (!card) return;
        const title = card.querySelector('h3')?.textContent.trim();
        if (title) {
            let savedCourses = JSON.parse(localStorage.getItem('flashmaster_courses')) || [];
            savedCourses = savedCourses.filter(c => (typeof c === 'string' ? c : c.name).toLowerCase() !== title.toLowerCase());
            localStorage.setItem('flashmaster_courses', JSON.stringify(savedCourses));
        }
        card.remove();
    };
});
